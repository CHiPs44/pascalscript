extern int yyparse();

int main(void)
{
yyparse();
}