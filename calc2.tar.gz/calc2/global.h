#define YYSTYPE double
extern YYSTYPE yylval;
